// ============================================================
// App shell — boot, layout, tab routing, data loading & sync
// ============================================================

let promoters = [];
let jobs = [];
let stores = [];
let salesReports = [];
let dayPhotos = [];
let dayFeedback = [];
let shiftReports = [];
let currentTab = 'home';
let reportMonth = new Date().toISOString().slice(0,7);
let realtimeChannel = null;

// Local-only identity, on top of the real Supabase account login below —
// a per-device display name (like the promoter app's "which promoter are
// you?" step) so the header/stock form can show who's using it, without
// needing that to double as the account email.
let currentAdminName = localStorage.getItem('gp_admin_name') || null;

function stockRecordAttribution(){
  return { promoter_id:null, logged_by_admin_name:currentAdminName };
}

// Hooks used by the shared sales/stock modules (js/sales-section.js,
// js/locations.js). The promoter app defines its own versions.
function salesActorName(){ return currentAdminName || 'Admin'; }
function salesActorPromoterId(){ return null; }
function canEditPastSales(){ return true; }
function canManageStockLocations(){ return true; }

function boot(){
  const root = document.getElementById('root');

  if(typeof DB === 'undefined' || typeof sb === 'undefined'){
    root.innerHTML = `
      <div class="phone" style="align-items:center; justify-content:center; text-align:center; padding:32px;">
        <img class="brand-mark" src="assets/icon-192.png" alt="Golden Panda logo" style="width:52px;height:52px;border-radius:14px;margin-bottom:18px;">
        <h2 style="font-family:'Fraunces',serif; font-size:18px;">Couldn't start the app</h2>
        <p style="font-size:13px; color:var(--ink-soft); max-width:320px;">
          A required script failed to load (likely <code>js/vendor/supabase-sdk.js</code>).
          Open your browser's console (F12) for the exact error, and make sure every file
          from the app folder — not just index.html — was deployed.
        </p>
      </div>
    `;
    return;
  }

  checkAuthThenProceed();
}

async function checkAuthThenProceed(){
  let session;
  try{
    session = await Auth.getSession();
  }catch(e){
    console.error(e);
    session = null;
  }
  if(session){
    if(!currentAdminName){
      renderNameGate();
    }else{
      renderApp();
    }
  }else{
    renderAuthGate('login');
  }
}

// mode is 'login' or 'signup'
function renderAuthGate(mode, prefillEmail){
  const root = document.getElementById('root');
  const isSignup = mode === 'signup';
  root.innerHTML = `
    <div class="gate">
      <img class="brand-mark" src="assets/icon-192.png" alt="Golden Panda logo">
      <h2>${isSignup ? 'Create your account' : 'Log in'}</h2>
      <p>${isSignup
        ? 'First time here? Set a password to log in with next time.'
        : 'Enter your email and password to open the office app.'}</p>
      <div class="gate-form">
        <label for="auth-email">Email address</label>
        <input id="auth-email" type="email" inputmode="email" placeholder="name@example.com" value="${prefillEmail ? esc(prefillEmail) : ''}" autocapitalize="off" autocomplete="email">
        <label for="auth-password">Password</label>
        <input id="auth-password" type="password" placeholder="Enter your password" autocomplete="${isSignup?'new-password':'current-password'}">
        <button class="btn btn-primary btn-block" id="auth-submit-btn" onclick="${isSignup?'submitSignup()':'submitLogin()'}">${isSignup ? 'Create account' : 'Log in'}</button>
      </div>
      <p class="fineprint">
        ${isSignup
          ? `Already have an account? <a href="#" onclick="event.preventDefault(); renderAuthGate('login')">Log in</a>`
          : `No account yet? <a href="#" onclick="event.preventDefault(); renderAuthGate('signup')">Create one</a>`}
      </p>
    </div>
  `;
  document.getElementById('auth-email').focus();
  document.getElementById('auth-password').addEventListener('keydown', e=>{
    if(e.key === 'Enter') isSignup ? submitSignup() : submitLogin();
  });
}

async function submitSignup(){
  const email = document.getElementById('auth-email').value.trim();
  const password = document.getElementById('auth-password').value;
  if(!email || !password){ showToast('Enter an email and password'); return; }
  if(password.length < 6){ showToast('Password must be at least 6 characters'); return; }

  const btn = document.getElementById('auth-submit-btn');
  btn.disabled = true; btn.textContent = 'Creating account…';
  try{
    const result = await Auth.signUp(email, password);
    if(result.session){
      // Signed in immediately (email confirmation is off in this project).
      checkAuthThenProceed();
    }else{
      // Email confirmation is on — they need to click a link before logging in.
      showToast('Account created — check your email to confirm, then log in');
      renderAuthGate('login', email);
    }
  }catch(e){
    console.error(e);
    showToast(e.message || 'Could not create account');
    btn.disabled = false; btn.textContent = 'Create account';
  }
}

async function submitLogin(){
  const email = document.getElementById('auth-email').value.trim();
  const password = document.getElementById('auth-password').value;
  if(!email || !password){ showToast('Enter your email and password'); return; }

  const btn = document.getElementById('auth-submit-btn');
  btn.disabled = true; btn.textContent = 'Logging in…';
  try{
    await Auth.signIn(email, password);
    checkAuthThenProceed();
  }catch(e){
    console.error(e);
    showToast(e.message || 'Could not log in');
    btn.disabled = false; btn.textContent = 'Log in';
  }
}

// Simple name gate — free text, no picking from a list (there's no fixed
// roster of "admins" the way there is a roster of promoters). Shown once
// per device after a successful account login (see checkAuthThenProceed),
// same as the promoter app asks "which promoter are you?" after its own
// login. Saved to this device so it's only asked once.
function renderNameGate(){
  const root = document.getElementById('root');
  root.innerHTML = `
    <div class="gate">
      <img class="brand-mark" src="assets/icon-192.png" alt="Golden Panda logo">
      <h2>Who's logging in?</h2>
      <p>Enter your name — it stays saved on this device so you won't need to enter it again next time.</p>
      <div class="gate-form">
        <label for="gate-admin-name">Your name</label>
        <input id="gate-admin-name" type="text" placeholder="e.g. Aisyah" autocapitalize="words" autocomplete="name" value="${currentAdminName?esc(currentAdminName):''}">
        <button class="btn btn-primary btn-block" onclick="submitAdminName()">Continue</button>
      </div>
      <p class="fineprint">Not you on this device in future? Tap your name at the top of the app to log out.</p>
    </div>
  `;
  const input = document.getElementById('gate-admin-name');
  input.focus();
  input.addEventListener('keydown', e=>{ if(e.key==='Enter') submitAdminName(); });
}

function submitAdminName(){
  const name = document.getElementById('gate-admin-name').value.trim();
  if(!name){ showToast('Enter your name'); return; }
  currentAdminName = name;
  localStorage.setItem('gp_admin_name', name);
  renderApp();
}

function logOutAdmin(){
  if(!confirm('Log out of this app on this device?')) return;
  localStorage.removeItem('gp_admin_name');
  currentAdminName = null;
  if(realtimeChannel) sb.removeChannel(realtimeChannel);
  Auth.signOut().catch(e=>console.error(e));
  renderAuthGate('login');
}

function renderApp(){
  const root = document.getElementById('root');
  root.innerHTML = `
    <div class="phone">
      <div class="app-header">
        <div class="brand-row">
          <img class="brand-mark" src="${APP_LOGO_SRC}" alt="Golden Panda logo">
          <div class="brand-text">
            <h1>Golden Panda</h1>
            <p>Retail Operation</p>
          </div>
          <button type="button" class="identity-chip" id="identity-chip" onclick="logOutAdmin()" title="Log out ${esc(currentAdminName)}">
            <span class="sync-dot off" id="sync-dot" role="img" aria-label="Connection status"></span>
            <span class="identity-name">${esc(currentAdminName)}</span>
          </button>
        </div>
      </div>
      <main class="content" id="content"><div class="loading-state" role="status"><span class="loading-spinner" aria-hidden="true"></span>Loading your workspace…</div></main>
      <div class="fab" id="fab">
        <button type="button" class="fab-memo hidden" onclick="openMemoSection()" aria-label="Open memo notes" title="Memo">
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5"/><path d="M9 13h7M9 17h5"/></svg>
        </button>
        <button type="button" class="fab-primary" onclick="openFab()" aria-label="Add job">+</button>
        <button type="button" class="fab-photo hidden" onclick="openSkuRecord()" aria-label="SKU Record" title="SKU Record">
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-8 9"/></svg>
        </button>
        <button type="button" class="fab-calendar hidden" onclick="openWorkDateForm()" aria-label="Add working date without promoter" title="Add working date without promoter">
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>
        </button>
      </div>
      <nav class="tabbar" aria-label="Main navigation">
        <button type="button" class="tab" data-tab="sales" onclick="switchTab('sales')">
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M21 8L12 3 3 8l9 5 9-5Z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/></svg>
          <span>Sales Section</span>
        </button>
        <button type="button" class="tab" data-tab="stock" onclick="switchTab('stock')">
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="7" width="18" height="14" rx="1.5"/><path d="M3 7l3.5-4h11L21 7"/><path d="M9 12h6"/></svg>
          <span>Stock Management</span>
        </button>
        <button type="button" class="tab tab-home" data-tab="home" onclick="switchTab('home')" aria-label="Home">
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/></svg>
        </button>
        <button type="button" class="tab" data-tab="roster" onclick="switchTab('roster')">
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>
          <span>Schedule</span>
        </button>
        <button type="button" class="tab" data-tab="reports" onclick="switchTab('reports')">
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.66 3.58 3 8 3s8-1.34 8-3V6"/><path d="M4 12v6c0 1.66 3.58 3 8 3s8-1.34 8-3v-6"/></svg>
          <span>Payout</span>
        </button>
      </nav>
    </div>
  `;
  loadInitialData();
}

async function loadInitialData(){
  try{
    await DB.purgeOldJobs().catch(e=>console.warn('Purge old jobs failed (non-fatal):', e));
    await DB.purgeOldSalesReports().catch(e=>console.warn('Purge old sales reports failed (non-fatal):', e));
    await DB.purgeOldSalesLog().catch(e=>console.warn('Purge old sales log failed (non-fatal):', e));
    await DB.purgeOldDayPhotos().catch(e=>console.warn('Purge old day photos failed (non-fatal):', e));
    await DB.purgeOldDayFeedback().catch(e=>console.warn('Purge old day feedback failed (non-fatal):', e));
    await refreshData();
    await linkAllScheduledLocations().catch(e=>console.warn('Link scheduled locations failed (non-fatal):',e));
    await ensureTodaysStockRows().catch(e=>console.warn('Auto-seed today\'s stock rows failed (non-fatal):', e));
    await refreshData(); // re-fetch so any newly auto-created rows show up
    try{ skuCatalog = await DB.getSkus(); await ensureSkuCatalog(); }
  catch(e){ console.warn('Could not load the SKU list (non-fatal):', e); }
  setSyncDot(true);
    subscribeRealtime();
    startJobReminderChecks();
  }catch(e){
    console.error(e);
    setSyncDot(false);
    showToast('Could not connect to Supabase — check your internet connection');
  }
  switchTab(openTappedScheduleReminder() ? 'roster' : 'home');
}

// Re-fetches promoters, jobs, stores, stock locations, sales reports, the
// viewed day's sales log, day photos, day feedback, and shift reports.
async function refreshData(){
  const [p, j, s, sr, dp, df, shr, locations] = await Promise.all([
    DB.getPromoters(), DB.getJobs(), DB.getStores(), DB.getSalesReports(), DB.getDayPhotos(), DB.getDayFeedback(), DB.getShiftReports(),
    DB.getStockLocations()
  ]);
  promoters = p;
  jobs = j;
  stores = s;
  salesReports = sr;
  dayPhotos = dp;
  dayFeedback = df;
  shiftReports = shr;
  stockLocations = locations;
  // The tap log (for Undo) is a nice-to-have: a failure here must not take the whole app down.
  try{ salesLog = await DB.getSalesLogForDate(salesEffectiveViewDate()); }
  catch(e){ console.warn('Could not load sales history (non-fatal):', e); }
  // Product photos are optional: never let them take the app down.
  try{ productPhotos = await DB.getProductPhotos(); }
  catch(e){ console.warn('Could not load product photos (non-fatal):', e); }
  setSyncDot(true);
}

// Live sync: any change made from another phone updates this view automatically.
function subscribeRealtime(){
  if(realtimeChannel) sb.removeChannel(realtimeChannel);
  realtimeChannel = sb
    .channel('gp-staffing-changes')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'promoters' }, handleRemoteChange)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'jobs' }, handleRemoteJobChange)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'stores' }, handleRemoteChange)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'sales_reports' }, handleRemoteChange)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'day_photos' }, handleRemoteChange)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'day_feedback' }, handleRemoteChange)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'shift_reports' }, handleRemoteChange)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'sales_log' }, handleRemoteChange)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'stock_locations' }, handleRemoteChange)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'product_photos' }, handleRemoteChange)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'skus' }, handleRemoteChange)
    .subscribe(status=>{
      setSyncDot(status === 'SUBSCRIBED');
    });
}

// A change to the Schedule (from any device) also brings stock rows in line.
async function handleRemoteJobChange(){
  await handleRemoteChange();
  if(document.querySelector('.modal-overlay')) return;
  try{
    if(await syncStockWithSchedule()){
      await refreshData();
      render();
    }
  }catch(e){
    console.warn('Stock sync failed (non-fatal):', e);
  }
}

async function handleRemoteChange(){
  // Don't yank the screen while someone is mid-edit in a form.
  if(document.querySelector('.modal-overlay')) return;
  try{
    await refreshData();
    await checkJobReminders();
    render();
  }catch(e){
    console.error(e);
    setSyncDot(false);
  }
}

// ---------- Tabs ----------
function switchTab(tab){
  if(tab === 'roster' && typeof requestJobNotificationsFromScheduleTap === 'function'){
    requestJobNotificationsFromScheduleTap();
  }
  currentTab = tab;
  document.querySelectorAll('.tab').forEach(b=>{
    const active = b.dataset.tab===tab;
    b.classList.toggle('active', active);
    if(active) b.setAttribute('aria-current','page'); else b.removeAttribute('aria-current');
  });
  render();
  const content = document.getElementById('content');
  if(content) content.scrollTop = 0;
}

function openFab(){
  if(currentTab==='roster'){
    if(rosterPage==='schedule') openJobForm();
    else openPromoterForm();
  }
  else if(currentTab==='sales') openSalesForm();
  else if(currentTab==='stock') openSkuListSheet();
  else showToast('Switch to Schedule, Sales Section, or Stock Management to add');
}

function render(){
  document.querySelectorAll('.tab').forEach(b=>{
    const active = b.dataset.tab===currentTab;
    b.classList.toggle('active', active);
    if(active) b.setAttribute('aria-current','page'); else b.removeAttribute('aria-current');
  });
  const c = document.getElementById('content');
  if(!c) return;
  // The Sales Section has an inline notes box — don't wipe a half-typed note
  // when a +/- tap or a live update redraws the screen.
  const notesDraft = currentTab==='sales' ? captureNotesDraft() : null;
  if(currentTab==='home') c.innerHTML = renderHome();
  else if(currentTab==='roster') c.innerHTML = renderRosterSection();
  else if(currentTab==='sales') c.innerHTML = renderSalesSection();
  else if(currentTab==='stock') c.innerHTML = renderStockManagement();
  else c.innerHTML = renderReports();
  if(currentTab==='reports') wireReportControls();
  else if(currentTab==='roster') wireRosterSectionControls();
  else if(currentTab==='home') wireStockExportControls();
  else if(currentTab==='sales') restoreNotesDraft(notesDraft);

  // No "+" on Home, Payout or the Sales Report (SKUs are added in Stock Management and then appear in Sales). The
  // memo button only appears on Schedule, above the "+".
  const fab = document.getElementById('fab');
  if(fab){
    fab.classList.toggle('hidden', currentTab==='reports' || currentTab==='home' || currentTab==='sales');
    const label = currentTab==='roster' ? (rosterPage==='schedule' ? 'Add job' : 'Add promoter') : currentTab==='sales' ? 'Add sales report' : 'Add stock record';
    const button = fab.querySelector('.fab-primary');
    if(button){
      button.setAttribute('aria-label',label);
      button.title = label;
    }
    const calendarButton = fab.querySelector('.fab-calendar');
    if(calendarButton) calendarButton.classList.toggle('hidden', !(currentTab==='roster' && rosterPage==='schedule'));
    const photoButton = fab.querySelector('.fab-photo');
    if(photoButton) photoButton.classList.toggle('hidden', currentTab!=='stock');
    const memoButton = fab.querySelector('.fab-memo');
    if(memoButton) memoButton.classList.toggle('hidden', currentTab!=='roster');
  }
}

// ---------- Service worker (offline shell + installability) ----------
if('serviceWorker' in navigator){
  window.addEventListener('load', ()=>{
    navigator.serviceWorker.register('service-worker.js').catch(err=>console.warn('SW registration failed', err));
  });
}

// ---------- Init ----------
boot();
